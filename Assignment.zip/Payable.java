public interface Payable {
    double calculatePayment();
}
